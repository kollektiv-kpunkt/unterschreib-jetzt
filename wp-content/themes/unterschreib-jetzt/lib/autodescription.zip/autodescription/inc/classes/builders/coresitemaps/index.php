<?php
/**
 * The great questions of the day will not be settled by means of speeches and
 * majority descisions, but by iron and blood.
 *
 * - Otto von Bismarck
 */
