<?php
/**
 * No no, don't speak! For some moments in life there are no words.
 *
 * - David Seltzer
 *
 * (probably, uncredited: it's based on "Charlie and the Chocolate Factory" by Roald Dahl, but it's verbatim to the book;
 * the screenwriting was edited so much that Roald ultimately decided to disowned the film)
 */
