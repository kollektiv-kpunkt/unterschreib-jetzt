<?php
/**
 * Home wasn't built in a day.
 *
 * - Jane "Sherwood" Ace[-Epstein]
 */
