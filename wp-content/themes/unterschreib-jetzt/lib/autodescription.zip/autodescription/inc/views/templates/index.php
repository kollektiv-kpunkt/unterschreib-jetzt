<?php
/**
 * Life is a great big canvas, and you should throw all the paint on it you can.
 *
 * - Danny Kaye
 */
