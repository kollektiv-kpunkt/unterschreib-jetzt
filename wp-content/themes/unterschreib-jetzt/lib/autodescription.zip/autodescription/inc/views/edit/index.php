<?php
/**
 * When power leads men towards arrogance, poetry reminds him of his limitations.
 * When power narrows the areas of man’s concern, poetry reminds him of the richness and diversity of existence.
 * When power corrupts, poetry cleanses.
 *
 * - John F. Kennedy
 */
