<?php
global $i18n;
include __DIR__ . "/i18n/de.php";
?>

</div>

<?php
wp_footer();
?>

</body>
</html>