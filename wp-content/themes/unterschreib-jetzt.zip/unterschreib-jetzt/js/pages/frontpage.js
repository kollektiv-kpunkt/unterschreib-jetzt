jQuery("#mobile-fab").click(function(){
    jQuery("aside").addClass("form");
})

jQuery(".close-icon").click(function(){
    jQuery("aside").removeClass("form");
})