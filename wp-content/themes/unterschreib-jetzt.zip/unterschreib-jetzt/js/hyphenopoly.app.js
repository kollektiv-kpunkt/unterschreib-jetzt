var Hyphenopoly = {
    require: {
        "de": "FORCEHYPHENOPOLY",
        "fr": "FORCEHYPHENOPOLY",
        "it": "FORCEHYPHENOPOLY",
    },
    setup: {
        dontHyphenateClass: "nohyphen",
        exceptions: {
            "global": ""
        },
        selectors: {
            "#main-content": {}
        }
    }
};