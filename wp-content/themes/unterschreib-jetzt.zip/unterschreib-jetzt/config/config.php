<?php

$config = array(
    
    // EMAIL
    "email-username" => "info@unterschreib.jetzt",
    "email-pw" => "DJHQZt^Gr9@T",
    "email-host" => "victorinus.metanet.ch",
    "email-port" => 587,

);