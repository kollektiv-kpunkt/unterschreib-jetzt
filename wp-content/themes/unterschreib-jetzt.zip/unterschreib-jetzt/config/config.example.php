<?php

$config = array(
    
    // EMAIL
    "email-username" => "",
    "email-pw" => "",
    "email-host" => "",
    "email-port" => ,

);